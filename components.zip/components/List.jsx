import CollectionCard from './cards/CollectionCard'
import NewsCard from './cards/NewsCard'
import TeamCard from './cards/TeamCard'

export default function List({ shelf }) {
    const firstDomain = shelf.items[0]?.domain

    if (firstDomain === 'Team') {
        return (
            <div>
                <div className="border-t border-zinc-800 mx-6 mb-5" />
                <div className="px-6 mb-4">
                    <h2 className="text-white font-black text-base uppercase tracking-wide">{shelf.title}</h2>
                    {shelf.subtitle && <p className="text-zinc-400 text-xs mt-1">{shelf.subtitle}</p>}
                </div>
                <div className="md:hidden flex gap-4 overflow-x-auto px-6 pb-2 scrollbar-none">
                    {shelf.items.map(item => <TeamCard key={item.id} item={item} />)}
                </div>
                <div className="hidden md:grid md:grid-cols-6 lg:grid-cols-8 gap-4 px-6">
                    {shelf.items.map(item => <TeamCard key={item.id} item={item} />)}
                </div>
            </div>
        )
    }

    if (firstDomain === 'News') {
        return (
            <div>
                <div className="border-t border-zinc-800 mx-6 mb-5" />
                <div className="px-6 mb-4">
                    <h2 className="text-white font-black text-base uppercase tracking-wide">{shelf.title}</h2>
                    {shelf.subtitle && <p className="text-zinc-400 text-xs mt-1">{shelf.subtitle}</p>}
                </div>
                <div className="flex flex-col px-6 md:grid md:grid-cols-2 md:gap-x-8">
                    {shelf.items.map((item, i) => (
                        <div key={item.id}>
                            <NewsCard item={item} />
                            <div className="border-b border-zinc-800 my-4" />
                        </div>
                    ))}
                </div>
            </div>
        )
    }

    // Collection
    return (
        <div>
            <div className="border-t border-zinc-800 mx-6 mb-5" />
            <div className="px-6 mb-4">
                <h2 className="text-white font-black text-base uppercase tracking-wide">{shelf.title}</h2>
                {shelf.subtitle && <p className="text-zinc-400 text-xs mt-1">{shelf.subtitle}</p>}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-6">
                {shelf.items.map(item => <CollectionCard key={item.id} item={item} />)}
            </div>
        </div>
    )
}